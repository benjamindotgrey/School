// --------------------------
// Programmer:		Hassan Benjamin Shirani
// Course:			COSC 1336 Spring 2016
// Semester: 		Spring 2016
// Assignment #:	1b
// Due Date: 		February 03, 2016
// --------------------------

public class Quotes {

	public static void main(String[] args) {
		System.out.println("To be,");
		System.out.println(" or not to be,");
		System.out.println(" that is the question.");
		System.out.println();
		System.out.println("Or perhaps,");
		System.out.println("\tI should be asking,");
		System.out.println("\tsome other question!\n");
		System.out.println("This program was written by benjamin grey.");
		System.out.println("End of program.");
	} // end method main

} // end class Quotes
