// --------------------------
// Programmer:		Hassan Benjamin Shirani
// Course:			COSC 1336 Spring 2016
// Semester: 		Spring 2016
// Assignment #:	1a
// Due Date: 		February 03, 2016
// --------------------------

public class FirstJavaProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("This is my first Java program.");
		System.out.println();
		System.out.println("This program was written by Benjamin Shirani");
		System.out.println("End Program.");
	} // end method main

} // end class Assignment01a
